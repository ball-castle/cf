#include <bits/stdc++.h>
using namespace std;
uisng ll = long long;


/*
mex
对于静态数组 用vis处理
对于动态数组 涉及单点修改 插入删除 查询整个集合的mex
ct[x] == 0 存到set里面
*/



int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);


}
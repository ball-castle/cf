#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
vector<int> g[N];
bool visited[N];

void dfs(int u) {
    visited[u] = true;
    // the operation for every point
    for(int v : g[u]) {
        if(!visited[v]) dfs(v);
    }
}

int main() {
    int n, m; // n���㣬m����
    cin >> n >> m;
    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        g[a].push_back(b);
        g[b].push_back(a); // ���������ͼ
    }
    dfs(1); // �ӵ�1��ʼ����
    return 0;
}
